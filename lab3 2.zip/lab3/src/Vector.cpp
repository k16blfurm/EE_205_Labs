#include "../include/Vector.hpp"

#include <utility>
#include <iostream>

        // Use this method to double the capacity of
        // the current vector
        void Vector::double_capacity()
        {
        	//Doubling array by making new array (pointer) from previous
//        	int* array = new int[capacity * 2];
//        	int i = 0;
	std::cout<<"doubled"<<std::endl;
	if(capacity != 0)
	{
	capacity = capacity * 2;
	}
	else 
	capacity = capacity + 1;

        //copying array values from old array
//        for(i = 0; length != i; i++)
//        {
//        	array[i] = arr[i];
//        }

//		delete[] arr;
//		arr = array;
	}

    	//General Constructor
        Vector::Vector()
        {
        	arr = new int[1];
        	capacity = 1;
        	length = 0;
        }

        // Should perform a deep copy and allocate new
        // memory and copy the contents of the other
        // Vector over to this one.
        //Copy constructor
        Vector::Vector(const Vector& other)
        {
        		int capacity2, length2;
	                int i;
        		int* array = new int[capacity];
        		
        		length2 = other.length;
        		capacity2 = other.capacity;

        		//copying array values from old array
        		for(i = 0; length != i; i++)
        		{
        		array[i] = other.arr[i];
        		}

        		capacity = capacity2;
        		length = length2;
        		arr = array;
        } 

        // Should "steal" the contents of the other vector,
        // and set the memory and length in the other vector
        // to nullptr or zero  accordingly
        Vector::Vector(Vector&& other):arr(std::move(other.arr)),length(std::move(other.length))
        {
            capacity = other.capacity;
            other.arr = NULL;
            other.length = 0;
            other.capacity = 0;
        }

        // Should deallocate the memory.
        Vector::~Vector()
        {
            delete[] arr;
        }

        // For all of the following functions,
        // throw a const char* (string) if the index is out of
        // the bounds of the list.

        // Appends a number to the end of the vector.
        // 
        void Vector::append(int num) //automatically goes to end of array
        {

		std::cout<<"append"<<std::endl;

                if(length >= capacity)
                {
                    double_capacity();
                }
		    std::cout<<"num is"<<num<<std::endl;
                    arr[length] = num;

	    std::cout<<"exit append"<<std::endl;
            //Size of the array increases by 1
            length++;
	    

        }

        // Inserts a new number before the index (e.g. 0 
        // means at the front, this->length means at the back)
        // 
        // Throw a const char* if the index is out of bounds,
        // but appending at the end will still work (e.g.
        // vector.insert(vector.size(), 0) will work

        void Vector::insert(int index, int num) //automatically goes to beginning of array
        {   int i;
            int* array = new int[capacity];

	    std::cout<<"insert"<<std::endl;

            //saving the array to another array by +1
            if(index > (length + 1) || index < 0)
                throw "error";
            else if(this->length + 1 == this->capacity)
            { this->double_capacity();
	    }
	    
	    
                for(i = index; i < (length + 1); i++)
                {
                    array[i+1] = arr[i];
                }

		std::cout<<"insert length is"<<length<<std::endl;
		length++;

                for(i = index; i < length; i++)
                {
                    arr[i] = array[i];
                }

		std::cout<<"exit insert"<<std::endl;

                arr[index] = num;

                //deleting temporary array
                delete[] array;
            
        }

///////////////////////////Probably not going to work past here

        // Removes a number at the index 
        // 
        // Throw a const char* if the index is out of bounds
        void Vector::remove(int index)
        {
	std::cout<<"Entering Remove"<<std::endl;
            //ask if delete means remove and shift down or just put in a 0
            if(index >= length || index < 0)
                throw "error";
            else
            {
                for(int i = index; i < length; i++)
			arr[i] = arr[i + 1]; 
            
		length = length - 1;
	    }
	    std::cout<<"Exit remove"<<std::endl;
        }

        // Gets a number at the index
        // 
        // Throw a const char* if the index is out of bounds
        int Vector::get(int index) const
        { 
            if(index > capacity || index < 0)
            { 
		
                throw "error";
            }
	    else 
            {   
		std::cout<<"here in get";
		return arr[index]; 
            }

        }

        // Returns the length of the vector
        std::size_t Vector::size() const
        {
            return length;


        }

        // Returns a readable/writable referece to an element
        // 
        // Throw a const char* if the index is out of bounds
        int& Vector::operator[](int index) //operator[] is non-biased about what it sends back e.g. arrays or vectors
        {
            if(index > length || index < 0)
	    {
		throw "error"; 
            }
	    else
            {
                return arr[index];
            }
        }



