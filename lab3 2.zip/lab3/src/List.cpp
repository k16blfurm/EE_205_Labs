#include "../include/List.hpp"
#include <iostream>

#include <utility>

        // Initializes the list
        List::List()
	{
	//head = new ListNode(0);
	head = nullptr;
	length = 0;
//	ListNode* runner = head;

//	while(runner != nullptr)
//	{
//	std::cout<<runner->data<<std::endl;
//	runner=runner->next;
//	}



	}

        // Performs a deep copy, copying each node of the other list
        // into this one
        List::List(const List& other)
	{	ListNode* other_runner = other.head;
		this->head = new ListNode(other.head->data);
		ListNode* our_runner = this->head;
		//for(int i = 0;runner != nullptr ; i++)
		while(other_runner != nullptr)
		{
			our_runner->next = new ListNode(other_runner->next->data);
			other_runner = other_runner->next;
			our_runner = our_runner->next;
		}
		this->length = other.length;

	}

        // Performs a move, moving the internal list from the other
        // vector to this one, and invalidates the other list pointer
        // for its memory
        List::List(List&& other):head(std::move(other.head)),length(std::move(other.length))
	{

		//length = other.length;

//		delete [] head;
//		head[] = other.head;
		other.head = nullptr;
		other.length = 0;
	}

        // Deallocates the memory in this list.
        List::~List()
	{ListNode* runner = head; 


		while(runner != nullptr)
		{ 
			head = runner;
			runner = runner->next;
			delete head;
		}
	}

        // For all of the following functions,
        // throw a const char* (string) if the index is out of
        // the bounds of the list.

        // Appends a ListNode onto the end of the list
        //
        // Throw a const char* if the index is out of bounds
        void List::append(int num)
	{ListNode* runner = head; 
		std::cout<<"Im in append"<<std::endl;

	if(head ==NULL)
	{head = new ListNode(num);
	}
	

	else{
	while(runner->next != NULL)
	{runner = runner->next;}

	runner->next = new ListNode(num);

	}
	length++;

	std::cout<<"Im leaving append"<<std::endl;
        //Size of the array increases by 1
       //     length++;
	}

        // Inserts a ListNode before the index
        //
        // Throw a const char* if the index is out of bounds.
        // Appending at the end is valid (e.g. insert(list.size(), 0)
        // is valid)
        void List::insert(int index, int num)
	{
		std::cout<<"Im in insert"<<std::endl;
	    if(index > length || index < 0)
            throw "error";
            //else if(this->length + 1 == this->capacity)
            //{ this->double_capacity();
            //}
	   else if(index == length)
	   {
	   append(num);
	   }
	   else if(index == 0)
	   {ListNode* temp = new ListNode(num);
	    temp->next = head;
	    head = temp; 
	    length++;
	   }
	   else
	  {ListNode* temp = new ListNode(num);
	   ListNode* temp2;
	   ListNode* runner = head; 
	   int i = 0;
	   while((index-1) != i)
	   {
	     runner = runner->next;

	   i++;
	   }
	   temp2=runner->next;

	  
	   runner->next = temp;
	   temp->next = temp2;
	   length++;
	  }

	std::cout<<"Im leaving insert"<<std::endl;

	}

        // Removes the ListNode at the index
        //
        // Throw a const char* if the index is out of bounds.
        void List::remove(int index)
	{
	std::cout<<"Here in remove"<<std::endl; 
	if(index >= length || index < 0)
                throw "error";
            else if(index == 0)
            {  ListNode* temp2 = head;
	std::cout<<"remove index == 0"<<std::endl; 
             	head = head->next;
		delete temp2;
		length--;
		std::cout<<"here in index ==0"<<std::endl;
            }
        else
	{ ListNode* runner = head;
	std::cout<<"Remove base case"<<std::endl; 
	  ListNode* temp;
	int i = 0;

        std::cout<<"here in base"<<std::endl;
	while((index-1) != i)
           {
           runner = runner->next;

           i++;
           }
          length--;
           temp = runner->next;
	   runner->next = runner->next->next;
	   delete temp;
          }
	std::cout<<"Leaving remove"<<std::endl; 
	}

        // Returns the int at the index
        //
        // Throw a const char* if the index is out of bounds.
        int List::get(int index) const
	{ListNode* runner = head;
	if(index >= length || index < 0)
                throw "error";
	else
	{int i = 0;
	while((index) != i)
	{
	runner = runner->next;
	i++;
	}

	return runner->data;
	}
	}

        // Returns the length of the list
        std::size_t List::size() const
	{
		return this->length;
	}

        // Reutrns a readable/writeable reference to the element at index
        //
        // Throw a const char* if the index is out of bounds.
        int& List::operator[](int index)
	{
	ListNode* runner = head;
        if(index >= length || index < 0)
                throw "error";
        else
        {int i = 0;
        while((index) != i)
        {
        runner = runner->next;
	i++;
        }

        return runner->data;
        }
	}
