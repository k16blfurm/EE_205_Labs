// Knowledge Check from website

#include <iostream>
    using namespace std;
    class CDummy
    {
        public:
		int var1;
        // This is a reference Variable that is located int CDummy
        int isitme (CDummy& param); //I'm pretty sure this is a declaring the function exists in the class with a point to the class (CDummy& 
                                    // param being the variable sent (a or c).)
    };
    int CDummy::isitme (CDummy& param)
    {
        if (&param == this)
            return true;
        else
            return false;
    }
    int main ()
    {
        //This is making two different versions of the classes... a and c, while making a pointer to a from b (For var1). Also, for class CDummy
        CDummy a,c;
        CDummy *b = &a;
		
        //Assigning values to different versions of the class
		a.var1 = 1;
		b->var1 = 2; //using the pointer needed to save values to the referenced a (which makes a = 1)
		c.var1 = 2;
		
        if (b->isitme(a)) //pointer to a from the function?
        {
            cout << "Start Action 1 \n";
			
			if(c.var1==a.var1){ //c should equal to a because of the pointer to it in the CDummy above
				cout << "Repeat Action 1 \n"; //thats why in the unmodified program, this is the output
			}else{
					cout << "End Action 1 \n";
			}
        }
        else //showing that the pointer b doesn't point to a, but still checks for equality for var1
        {
            cout<<"Start Action 2";
			
			if(c.var1==a.var1){
				cout << "Continue Action 2 \n";
			}else{
					cout << "End Action 2 \n";
			}
        }
        return 0;
    }