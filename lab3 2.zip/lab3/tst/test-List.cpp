#include <iostream>
#include <cassert>
#include "List.hpp"

int main() {
	std::cout<<"DEBUG1"<<std::endl;
    List v;

	std::cout<<"DEBUG2"<<std::endl;
    auto print_list = [](List& l) {
        for (int i = 0; i < l.size() ; ++i) {
            std::cout << "l[" << i << "]: " << l[i] << std::endl;
        }
    };

	std::cout<<"DEBUG3"<<std::endl;
    v.insert(0, 0);
    print_list(v);
	std::cout<<v.size()<<std::endl;
	std::cout<<"DEBUG4"<<std::endl;
    v.insert(v.size(), 1);
	std::cout<<v.size()<<std::endl;
    print_list(v);

	std::cout<<"DEBUG5"<<std::endl;
    v.append(2);
    print_list(v);

	std::cout<<"DEBUG6"<<std::endl;

    for (int i = 0; i < v.size(); ++i) {
        assert(i == v.get(i));
        assert(i == v[i]);
        v[i] = i+1;
        assert(v.size() == 3);
    }

	std::cout<<"DEBUG7"<<std::endl;
    for (int i = 0; i < v.size(); ++i) {
        assert(i+1 == v.get(i));
        assert(i+1 == v[i]);
        assert(v.size() == 3);
    }

	std::cout<<"DEBUG8"<<std::endl;
    for (int i = 0; i < v.size(); ++i) {
        std::cout << "v[" << i << "]: " << v[i] << std::endl;
    }

	std::cout<<"DEBUG9"<<std::endl;
    v.remove(0);
	std::cout<<"DEBUG10"<<std::endl;
    for (int i = 0; i < v.size(); ++i) {
        std::cout << "v[" << i << "]: " << v[i] << std::endl;
    }
	std::cout<<"DEBUG11"<<std::endl;
    assert(v[0] == 2);
	std::cout<<"DEBUG12"<<std::endl;
    assert(v[1] == 3);

	std::cout<<"DEBUG13"<<std::endl;
    try {
        v.remove(-1);
    } catch (char const* c) {
        std::cout << c << std::endl;
        assert(true); 
    } catch (...) {
        assert(false);
    }
	std::cout<<"DEBUG14"<<std::endl;
    v.remove(0);
	std::cout<<"DEBUG15"<<std::endl;
    assert(v.size() == 1);
	std::cout<<"DEBUG16"<<std::endl;
    v.remove(0);
	std::cout<<"DEBUG17"<<std::endl;
    assert(v.size() == 0);
	std::cout<<"DEBUG18"<<std::endl;
    try {
        v.remove(0);
    } catch (char const* c) {
        std::cout << c << std::endl;
        assert(true); 
    } catch (...) {
        assert(false);
    }

	std::cout<<"DEBUG19"<<std::endl;
    v.append(1);
	std::cout<<"DEBUG20"<<std::endl;
    List w(std::move(v));

	std::cout<<"DEBUG21"<<std::endl;
    assert(v.size() == 0);
    std::cout << w.size() << std::endl;
    assert(w.size() == 1);
    assert(w[0] == 1);

    std::cout << std::endl;
    std::cout << "SUCCESS" << std::endl;
    return 0;
}
